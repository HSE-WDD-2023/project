from flask import Flask, render_template, request, redirect, session, flash
from flask_session import Session

app = Flask(__name__)

# Configure Session
app.config["SESSION_PERMENANT"] = False
app.config["SESSION_TYPE"] = 'filesystem'
Session(app)


# Create all your routes below here

@app.route("/")
def index():
    return render_template("index.html")
