-- run this file by typing sqlite3 -cmd ".read setup.sql" from your terminal

.open project.db -- this will be the name of your database
.mode box        -- for nicer looking output


-- drop the tables

-- create your tables

-- add some starter data to your tables using INPUT statemtns

-- show all the starter data
