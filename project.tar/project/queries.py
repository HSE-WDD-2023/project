from cs50 import SQL

db = SQL("sqlite3///project.db")

# Create your functions for working with your database below here
